package dam.alumno.filmoteca;

import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MainApp extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        System.out.println("Cargando archivo FXML...");
        FXMLLoader fxmlLoader = new FXMLLoader(MainApp.class.getResource("MainView.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 800, 600);

        System.out.println("Cargando hoja de estilos...");
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());

        stage.setTitle("Filmoteca");

        stage.setMinWidth(1200);
        stage.setMinHeight(650);

        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }

    public void init() {
        System.out.println("Cargando datos desde el fichero datos/peliculas.json...");
        DatosFilmoteca datosFilmoteca = DatosFilmoteca.getInstance();
        ObjectMapper objectMapper = new ObjectMapper();

        try {
            List<Pelicula> lista = objectMapper.readValue(
                    new File("filmoteca/datos/peliculas.json"),
                    objectMapper.getTypeFactory().constructCollectionType(List.class, Pelicula.class)
            );

            datosFilmoteca.getListaPeliculas().setAll(lista);
        } catch (IOException e){
            System.out.println("ERROR al cargar los datos. La aplicación no puede iniciarse");
            e.printStackTrace();
            System.exit(1);
        }

        System.out.println(datosFilmoteca.getListaPeliculas());
    }

    public void stop() {
        System.out.println("Guardando datos en el fichero datos/peliculas2.json...");
        ObservableList<Pelicula> listaPeliculas = DatosFilmoteca.getInstance().getListaPeliculas();
        System.out.println(listaPeliculas);
        ObjectMapper objectMapper = new ObjectMapper();

        try {
            objectMapper.writeValue(new File("filmoteca/datos/peliculas2.json"), listaPeliculas);
        } catch (IOException e) {
            System.out.println("ERROR no se ha podido guardar los datos de la aplicación");
            e.printStackTrace();
        }
    }
}