package dam.alumno.filmoteca;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;

public class MainController {

    @FXML private TableView<Pelicula> movieTable;
    @FXML private TableColumn<Pelicula, Integer> columnId;
    @FXML private TableColumn<Pelicula, String> columnTitle;
    @FXML private TableColumn<Pelicula, String> columnYear;
    @FXML private TableColumn<Pelicula, String> columnDirector;
    @FXML private TableColumn<Pelicula, Float> columnRating;

    @FXML public Text textTitle;
    @FXML public Text textYear;
    @FXML public Text textDescription;
    @FXML public Text textDirector;
    @FXML public Text textRating;
    @FXML public Text textPoster;

    private DatosFilmoteca singleton = DatosFilmoteca.getInstance();
    private ObservableList<Pelicula> listMovies;

    public void initialize() {
        listMovies = singleton.getListaPeliculas();

        columnId.setCellValueFactory(data -> data.getValue().idProperty().asObject());
        columnTitle.setCellValueFactory(data -> data.getValue().titleProperty());
        columnYear.setCellValueFactory(data -> data.getValue().yearProperty());
        columnDirector.setCellValueFactory(data -> data.getValue().directorProperty());
        columnRating.setCellValueFactory(data -> data.getValue().ratingProperty().asObject());

        movieTable.setItems(listMovies);

        movieTable.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                textTitle.textProperty().bind(newValue.titleProperty());
                textYear.textProperty().bind(newValue.yearProperty());
                textDescription.textProperty().bind(newValue.descriptionProperty());
                textDirector.textProperty().bind(newValue.directorProperty());
                textRating.textProperty().bind(newValue.ratingProperty().asString());
                textPoster.textProperty().bind(newValue.posterProperty());
            } else {
                textTitle.textProperty().unbind();
                textYear.textProperty().unbind();
                textDescription.textProperty().unbind();
                textDirector.textProperty().unbind();
                textRating.textProperty().unbind();
                textPoster.textProperty().unbind();
            }
        });
    }

    @FXML
    private void onAddMovie() {
        Scene escena = null;
        FXMLLoader fxmlLoader = new FXMLLoader(MainApp.class.getResource("MovieView.fxml"));
        try {
            escena = new Scene(fxmlLoader.load());
        } catch (IOException e) {
            System.out.println("ERROR al cargar la ventana de nueva película");
            e.printStackTrace();
        }

        MovieController controller = fxmlLoader.getController();
        controller.setTextViewTitle("Crear nueva película");

        Stage st = new Stage();
        st.setScene(escena);
        st.setTitle("Crear Nueva película");
        st.showAndWait();

        if (controller.isOKClicked()) {
            Pelicula newMovie = controller.getMovie();
            Pelicula p = Collections.max(listMovies, Comparator.comparingInt(Pelicula::getId));

            newMovie.setId(p.getId() + 1);
            movieTable.getItems().add(newMovie);
        }
    }

    @FXML
    private void onEditMovie() {
        int selected = movieTable.getSelectionModel().getSelectedIndex();

        if (selected < 0) {
            showAlert("Debe seleccionar una película para editar.");
            return;
        }

        Scene escena = null;
        FXMLLoader fxmlLoader = new FXMLLoader(MainApp.class.getResource("MovieView.fxml"));
        try {
            escena = new Scene(fxmlLoader.load());
        } catch (IOException e) {
            System.out.println("ERROR al cargar la ventana de modificar película");
            e.printStackTrace();
        }

        MovieController controller = fxmlLoader.getController();
        controller.setTextViewTitle("Editar película");
        controller.setMovie(movieTable.getSelectionModel().getSelectedItem());

        Stage st = new Stage();
        st.setScene(escena);
        st.setTitle("Editar película");
        st.showAndWait();

        if (controller.isOKClicked()) {
            Pelicula modifiedMovie = controller.getMovie();
            Pelicula currentMovie = movieTable.getSelectionModel().getSelectedItem();

            currentMovie.setTitle(modifiedMovie.getTitle());
            currentMovie.setYear(modifiedMovie.getYear());
            currentMovie.setDescription(modifiedMovie.getDescription());
            currentMovie.setDirector(modifiedMovie.getDirector());
            currentMovie.setRating(modifiedMovie.getRating());
            currentMovie.setPoster(modifiedMovie.getPoster());
        }
    }

    @FXML
    private void onDeleteMovie() {
        int selected = movieTable.getSelectionModel().getSelectedIndex();

        if (selected >= 0) {
            boolean confirmed = confirmAction("¿Está seguro de que desea eliminar la película?");
            if (confirmed) {
                movieTable.getItems().remove(selected);
            }
        } else {
            showAlert("Debe seleccionar la película que desee eliminar.");
        }
    }

    @FXML
    private void onCloseApp() {
        boolean confirmed = confirmAction("¿Está seguro de que desea cerrar la aplicación?");
        if (confirmed) {
            System.exit(0);
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Mensaje de advertencia");
        alert.setContentText(message);
        alert.showAndWait();
    }

    private boolean confirmAction(String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Mensaje de confirmación");
        alert.setHeaderText(message);
        alert.setContentText("Elija una opción para continuar:");
        return alert.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK;
    }
}