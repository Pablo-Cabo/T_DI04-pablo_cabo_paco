package dam.alumno.filmoteca;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class MovieController implements Initializable {

    @FXML public Text viewTitle;
    @FXML public TextField fieldTitle;
    @FXML public TextField fieldYear;
    @FXML public TextField fieldDescription;
    @FXML public TextField fieldDirector;
    @FXML public Slider fieldRating;
    @FXML public TextField fieldPoster;

    private final DatosFilmoteca singleton = DatosFilmoteca.getInstance();
    private final ObservableList<Pelicula> listMovies = singleton.getListaPeliculas();

    private Pelicula newMovie = new Pelicula();
    private boolean okClick = false;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        fieldTitle.textProperty().bindBidirectional(newMovie.titleProperty());
        fieldYear.textProperty().bindBidirectional(newMovie.yearProperty());
        fieldDescription.textProperty().bindBidirectional(newMovie.descriptionProperty());
        fieldDirector.textProperty().bindBidirectional(newMovie.directorProperty());
        fieldRating.valueProperty().bindBidirectional(newMovie.ratingProperty());
        fieldPoster.textProperty().bindBidirectional(newMovie.posterProperty());
    }

    public void setTextViewTitle(String titulo) {
        viewTitle.setText(titulo);
    }

    public boolean isOKClicked () { return okClick; }

    public Pelicula getMovie () {
        return newMovie;
    }

    public void setMovie(Pelicula pelicula) {
        newMovie.setId(pelicula.getId());
        newMovie.setTitle(pelicula.getTitle());
        newMovie.setYear(pelicula.getYear());
        newMovie.setDescription(pelicula.getDescription());
        newMovie.setDirector(pelicula.getDirector());
        newMovie.setRating(pelicula.getRating());
        newMovie.setPoster(pelicula.getPoster());
    }

    @FXML
    public void onSave(ActionEvent actionEvent) {
        okClick = true;

        newMovie.setTitle(fieldTitle.getText());
        newMovie.setYear(fieldYear.getText());
        newMovie.setDescription(fieldDescription.getText());
        newMovie.setDirector(fieldDirector.getText());
        newMovie.setRating((float) fieldRating.getValue());
        newMovie.setPoster(fieldPoster.getText());

        Stage st = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        st.close();
    }

    @FXML
    public void OnCancel(ActionEvent actionEvent) {
        okClick = false;
        Stage st = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        st.close();
    }
}
